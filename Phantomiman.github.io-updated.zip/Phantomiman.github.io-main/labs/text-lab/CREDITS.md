# Credits

This directory contains **OakFort Text Lab**, maintained by **Sami Mirov (OakFort)**.

## Open‑source components

- **P4RS3LT0NGV3 - Universal Text Translator**  
  License: **GNU AGPL-3.0** (see `LICENSE`)  
  Source: included in this folder as required by the license.  
  Changes made by OakFort: branding, color theme, and wording adjusted to focus on defensive research utilities.

If you are the original author and prefer a different attribution format, please open an issue on the repository hosting this site.
